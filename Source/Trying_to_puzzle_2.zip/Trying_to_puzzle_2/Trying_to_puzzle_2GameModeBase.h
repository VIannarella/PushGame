// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "Trying_to_puzzle_2GameModeBase.generated.h"

/**
 * 
 */
UCLASS()
class TRYING_TO_PUZZLE_2_API ATrying_to_puzzle_2GameModeBase : public AGameModeBase
{
	GENERATED_BODY()
	
	
public: 
	ATrying_to_puzzle_2GameModeBase();
	
};
