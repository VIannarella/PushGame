// Fill out your copyright notice in the Description page of Project Settings.

#include "Trying_to_puzzle_2.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Trying_to_puzzle_2, "Trying_to_puzzle_2" );
